# -*- coding: utf-8 -*-
import fcntl
import os


class PidFile(object):
    """Context manager that locks a pid file.  Implemented as class
    not generator because daemon.py is calling .__exit__() with no parameters
    instead of the None, None, None specified by PEP-343.

    From http://code.activestate.com/recipes/577911-context-manager-for-a-daemon-pid-file/
    """

    def __init__(self, path):
        """Initializes path for pidfile"""
        self.path = os.path.realpath(path)
        self.pidfile = None

    def __enter__(self):
        """Writes the pid of the current process to the path"""
        self.pidfile = open(self.path, 'a+')
        try:
            fcntl.flock(self.pidfile.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except IOError:
            raise SystemExit('Already running according to {0}'.format(self.path))
        self.pidfile.seek(0)
        self.pidfile.truncate()
        self.pidfile.write(str(os.getpid()))
        self.pidfile.flush()
        self.pidfile.seek(0)
        return self.pidfile

    def __exit__(self, exc_type=None, exc_value=None, exc_tb=None):
        """Removes the pid for the current process"""
        try:
            self.pidfile.close()
        except IOError as err:
            # ok if file was just closed elsewhere
            if err.errno != 9:
                raise
        os.remove(self.path)
