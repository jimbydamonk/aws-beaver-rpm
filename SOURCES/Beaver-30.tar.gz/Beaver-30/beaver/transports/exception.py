# -*- coding: utf-8 -*-


class TransportException(Exception):
    pass
